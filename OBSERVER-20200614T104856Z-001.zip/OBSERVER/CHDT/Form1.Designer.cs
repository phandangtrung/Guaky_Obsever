﻿namespace CHDT
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnaddproduct = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tbname = new System.Windows.Forms.TextBox();
            this.tbid = new System.Windows.Forms.TextBox();
            this.tbdes = new System.Windows.Forms.TextBox();
            this.tbcategory = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.nmprice = new System.Windows.Forms.NumericUpDown();
            this.dtgvcus = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmprice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvcus)).BeginInit();
            this.SuspendLayout();
            // 
            // btnaddproduct
            // 
            this.btnaddproduct.Location = new System.Drawing.Point(344, 182);
            this.btnaddproduct.Name = "btnaddproduct";
            this.btnaddproduct.Size = new System.Drawing.Size(93, 127);
            this.btnaddproduct.TabIndex = 0;
            this.btnaddproduct.Text = "Update Product";
            this.btnaddproduct.UseVisualStyleBackColor = true;
            this.btnaddproduct.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(476, 12);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 62;
            this.dataGridView2.RowTemplate.Height = 28;
            this.dataGridView2.Size = new System.Drawing.Size(615, 190);
            this.dataGridView2.TabIndex = 5;
            this.dataGridView2.Click += new System.EventHandler(this.dataGridView2_Click);
            // 
            // tbname
            // 
            this.tbname.Location = new System.Drawing.Point(113, 94);
            this.tbname.Name = "tbname";
            this.tbname.Size = new System.Drawing.Size(324, 26);
            this.tbname.TabIndex = 7;
            // 
            // tbid
            // 
            this.tbid.Location = new System.Drawing.Point(113, 32);
            this.tbid.Name = "tbid";
            this.tbid.ReadOnly = true;
            this.tbid.Size = new System.Drawing.Size(85, 26);
            this.tbid.TabIndex = 8;
            // 
            // tbdes
            // 
            this.tbdes.Location = new System.Drawing.Point(113, 182);
            this.tbdes.Multiline = true;
            this.tbdes.Name = "tbdes";
            this.tbdes.Size = new System.Drawing.Size(225, 127);
            this.tbdes.TabIndex = 9;
            // 
            // tbcategory
            // 
            this.tbcategory.Location = new System.Drawing.Point(344, 32);
            this.tbcategory.Name = "tbcategory";
            this.tbcategory.ReadOnly = true;
            this.tbcategory.Size = new System.Drawing.Size(85, 26);
            this.tbcategory.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 20);
            this.label1.TabIndex = 11;
            this.label1.Text = "ID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(218, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 20);
            this.label2.TabIndex = 12;
            this.label2.Text = "IDCATEGORY:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(48, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 20);
            this.label3.TabIndex = 13;
            this.label3.Text = "Name :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(50, 137);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 20);
            this.label4.TabIndex = 14;
            this.label4.Text = "Price :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(5, 182);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 20);
            this.label5.TabIndex = 15;
            this.label5.Text = "Description :";
            // 
            // nmprice
            // 
            this.nmprice.Location = new System.Drawing.Point(113, 137);
            this.nmprice.Maximum = new decimal(new int[] {
            -727379968,
            232,
            0,
            0});
            this.nmprice.Name = "nmprice";
            this.nmprice.Size = new System.Drawing.Size(324, 26);
            this.nmprice.TabIndex = 16;
            // 
            // dtgvcus
            // 
            this.dtgvcus.BackgroundColor = System.Drawing.Color.White;
            this.dtgvcus.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvcus.Location = new System.Drawing.Point(476, 208);
            this.dtgvcus.Name = "dtgvcus";
            this.dtgvcus.RowHeadersWidth = 62;
            this.dtgvcus.RowTemplate.Height = 28;
            this.dtgvcus.Size = new System.Drawing.Size(615, 195);
            this.dtgvcus.TabIndex = 18;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1513, 437);
            this.Controls.Add(this.dtgvcus);
            this.Controls.Add(this.nmprice);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbcategory);
            this.Controls.Add(this.tbdes);
            this.Controls.Add(this.tbid);
            this.Controls.Add(this.tbname);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.btnaddproduct);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmprice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvcus)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnaddproduct;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TextBox tbname;
        private System.Windows.Forms.TextBox tbid;
        private System.Windows.Forms.TextBox tbdes;
        private System.Windows.Forms.TextBox tbcategory;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown nmprice;
        private System.Windows.Forms.DataGridView dtgvcus;
    }
}

